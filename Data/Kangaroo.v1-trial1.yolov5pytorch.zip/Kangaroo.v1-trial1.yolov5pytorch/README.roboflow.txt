
Kangaroo - v1 Trial1
==============================

This dataset was exported via roboflow.ai on April 24, 2022 at 9:34 AM GMT

It includes 163 images.
Kangaroos are annotated in YOLO v5 PyTorch format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


